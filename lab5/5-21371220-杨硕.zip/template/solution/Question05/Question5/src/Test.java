import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner1 = new Scanner(System.in);
        Scanner scanner2 = new Scanner(System.in);
        double a = scanner1.nextDouble();
        double b = scanner2.nextDouble();
        if (a < 0 || b < 0){
            Rectangle rectangle = new Rectangle();
            Rhombus rhombus = new Rhombus();
            Ellipse ellipse = new Ellipse();
            rectangle.setA(0.0);
            rectangle.setB(0.0);
            rhombus.setA(0.0);
            rhombus.setB(0.0);
            ellipse.setA(0.0);
            ellipse.setB(0.0);
            System.out.println(rectangle.calcArea());
            System.out.println(rhombus.calcArea());
            System.out.println(ellipse.calcArea());
        }
        else if (a >= 0 && b >= 0){
            Rectangle rectangle = new Rectangle();
            Rhombus rhombus = new Rhombus();
            Ellipse ellipse = new Ellipse();
            rectangle.setA(a);
            rectangle.setB(b);
            rhombus.setA(a);
            rhombus.setB(b);
            ellipse.setA(a);
            ellipse.setB(b);
            System.out.println(rectangle.calcArea());
            System.out.println(rhombus.calcArea());
            System.out.println(ellipse.calcArea());
        }
    }
}
