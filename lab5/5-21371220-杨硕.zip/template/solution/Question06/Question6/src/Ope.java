public enum Ope {
    NEW("New"),SELECT("Select"),OPEN("Open"),CLOSE("Close"),EDIT("Edit"),COPY("Copy"),CUT("Cut"),PASTE("Paste"),DELETE("Delete"),PRINT("Print");
    private String Name;
    private Ope(String name){
        this.Name = name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getName() {
        return Name;
    }
}
