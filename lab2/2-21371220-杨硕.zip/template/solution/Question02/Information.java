public class Information {
    public static void main(String[] args) {
        System.out.println("21371220");
        System.out.println("杨硕");
    }
}
