package com.oo;
import com.oo.cc.*;
public class Main {
	public static void main(String[] args) {
		System.out.println("main starts");
		C c = new C(1);
		System.out.println("yeah~");
	}
}