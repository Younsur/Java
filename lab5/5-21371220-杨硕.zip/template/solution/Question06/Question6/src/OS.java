import java.util.*;
import java.text.SimpleDateFormat;


class File {
    String Name;
    String Time;
    int Size;
    String Content;
    String Location;
    String Type;

}

class Folder extends File {
    private int fileNum;
    private int foldNum;
    private Ink ink;

    public void setInk(Ink ink) {
        this.ink = ink;
    }

    public Ink getInk() {
        return ink;
    }

    public void setFileNum(int fileNum) {
        this.fileNum = fileNum;
    }

    public int getFileNum() {
        return fileNum;
    }

    public void setFoldNum(int foldNum) {
        this.foldNum = foldNum;
    }

    public int getFoldNum() {
        return foldNum;
    }

    private TreeMap<String,File> fileTreeMap = new TreeMap<>();

    public TreeMap<String, File> getFileTreeMap() {
        return fileTreeMap;
    }
}

class Ink extends File {
    private File file;

    public void setFile(File file) {
        this.file = file;
    }

    public File getFile() {
        return file;
    }
}

class Exe extends File {
    private Ink ink;

    public void setInk(Ink ink) {
        this.ink = ink;
    }

    public Ink getInk() {
        return ink;
    }
}

class NonExe extends File {
    private Ink ink;

    public void setInk(Ink ink) {
        this.ink = ink;
    }

    public Ink getInk() {
        return ink;
    }
}
public class OS {
    public static Folder getFolder(String str) {
        for (Folder folder: folderTreeMap.values()){
            if (str.equals(folder.Name)){
                return folder;
            }
        }
        return null;
    }
    public static Ink getInk(String str) {
        for (Ink ink: inkTreeMap.values()){
            if (str.equals(ink.Name)){
                return ink;
            }
        }
        return null;
    }
    public static Exe getExe(String str){
        for (Exe exe: exeTreeMap.values()){
            if (str.equals(exe.Name)){
                return exe;
            }
        }
        return null;
    }
    public static NonExe getNonExe(String str) {
        for (NonExe nonExe: nonExeTreeMap.values()){
            if (str.equals(nonExe.Name)){
                return nonExe;
            }
        }
        return null;
    }

    public static int isselect = 0;
    public static int isopen = 0;
    public static int isfolder = 0;
    public static int isink = 0;
    public static int isexe = 0;
    public static int isnonexe = 0;
    public static Folder selectfolder;
    public static Ink selectink;
    public static Exe selectexe;
    public static NonExe selectnonexe;
    public static TreeMap<String,Folder> folderTreeMap = new TreeMap<>();
    public static TreeMap<String,Ink> inkTreeMap = new TreeMap<>();
    public static TreeMap<String,Exe> exeTreeMap = new TreeMap<>();
    public static TreeMap<String,NonExe> nonExeTreeMap = new TreeMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Ope ope = Ope.NEW;
        while (true){
            String operate = scanner.nextLine();
            if (operate.equals("QUIT")){
                isselect = 0;
                isfolder = 0;
                selectfolder = null;
                isexe = 0;
                selectexe = null;
                isink = 0;
                selectink = null;
                isnonexe = 0;
                selectnonexe = null;
                System.exit(0);
            }
            else {
                ope.setName(operate);
                switch (ope.getName()) {
                    case "New" -> {
                        String type = scanner.nextLine();
                        if (type.equals("New folder")) {
                            Folder folder = new Folder();
                            folder.Name = scanner.nextLine();
                            Date date = new Date();
                            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            folder.Time = dateFormat.format(date);
                            folder.Size = 0;
                            folder.Type = "folder";
                            if (isselect == 0) {
                                folder.Location = "C\\";
                                folderTreeMap.put(folder.Name, folder);
                            }
                            else if (isselect == 1 && isfolder == 0) {
                                System.out.println("Cannot perform operation");
                            }
                            else if (isselect == 1 && isfolder == 1) {
                                folder.Location = selectfolder.Location + selectfolder.Name + "\\";
                                folderTreeMap.put(folder.Name, folder);
                                selectfolder.getFileTreeMap().put(folder.Name, folder);
                                int cnt = selectfolder.getFoldNum();
                                cnt++;
                                selectfolder.setFoldNum(cnt);
                            }
                        }
                        else if (type.equals("New ink")) {
                            String[] selectFile = new String[2];
                            selectFile[0] = scanner.nextLine();
                            selectFile[1] = scanner.nextLine();
                            Ink ink = new Ink();
                            ink.Name = scanner.nextLine();
                            Date date = new Date();
                            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            ink.Time = dateFormat.format(date);
                            ink.Type = "ink";
                            if (selectFile[0].equals("folder")) {
                                Folder folder = getFolder(selectFile[1]);
                                ink.Size = folder.Size / 10;
                                ink.setFile(folder);
                                folder.setInk(ink);
                            }
                            else if (selectFile[0].equals("ink")) {
                                Ink ink1 = getInk(selectFile[1]);
                                ink.Size = ink1.Size;
                                ink.Content = ink1.Content;
                                ink.setFile(ink1);
                                ink1.setFile(ink);
                            }
                            else if (selectFile[0].equals("exe")) {
                                Exe exe = getExe(selectFile[1]);
                                ink.Size = exe.Size;
                                ink.Content = exe.Content;
                                ink.setFile(exe);
                                exe.setInk(ink);
                            }
                            else if (selectFile[0].equals("nonexe")) {
                                NonExe nonExe = getNonExe(selectFile[1]);
                                ink.Size = nonExe.Size;
                                ink.Content = nonExe.Content;
                                ink.setFile(nonExe);
                                nonExe.setInk(ink);
                            }
                            if (isselect == 0) {
                                ink.Location = "C\\";
                                inkTreeMap.put(ink.Name, ink);
                            }
                            else if (isselect == 1 && isfolder == 0) {
                                System.out.println("Cannot perform operation");
                            }
                            else if (isselect == 1 && isfolder == 1) {
                                ink.Location = selectfolder.Location + selectfolder.Name + "\\";
                                inkTreeMap.put(ink.Name, ink);
                                selectfolder.getFileTreeMap().put(ink.Name, ink);
                                int cnt = selectfolder.getFileNum();
                                cnt++;
                                selectfolder.setFileNum(cnt);
                                selectfolder.Size += ink.Size;
                            }
                        }
                        else if (type.equals("New exe")) {
                            Exe exe = new Exe();
                            exe.Name = scanner.nextLine();
                            Date date = new Date();
                            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            exe.Time = dateFormat.format(date);
                            exe.Content = scanner.nextLine();
                            exe.Size = exe.Content.length();
                            exe.Type = "exe";
                            if (isselect == 0) {
                                exe.Location = "C\\";
                                exeTreeMap.put(exe.Name, exe);
                            }
                            else if (isselect == 1 && isfolder == 0) {
                                System.out.println("Cannot perform operation");
                            }
                            else if (isselect == 1 && isfolder == 1) {
                                exe.Location = selectfolder.Location + selectfolder.Name + "\\";
                                exeTreeMap.put(exe.Name, exe);
                                selectfolder.getFileTreeMap().put(exe.Name, exe);
                                int cnt = selectfolder.getFileNum();
                                cnt++;
                                selectfolder.setFileNum(cnt);
                                selectfolder.Size += exe.Size;
                            }
                        }
                        else if (type.equals("New nonExe")) {
                            NonExe nonExe = new NonExe();
                            nonExe.Name = scanner.nextLine();
                            Date date = new Date();
                            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            nonExe.Time = dateFormat.format(date);
                            nonExe.Content = scanner.nextLine();
                            nonExe.Size = nonExe.Content.length();
                            nonExe.Type = "nonexe";
                            if (isselect == 0) {
                                nonExe.Location = "C\\";
                                nonExeTreeMap.put(nonExe.Name, nonExe);
                            }
                            else if (isselect == 1 && isfolder == 0) {
                                System.out.println("Cannot perform operation");
                            }
                            else if (isselect == 1 && isfolder == 1) {
                                nonExe.Location = selectfolder.Location + selectfolder.Name + "\\";
                                nonExeTreeMap.put(nonExe.Name, nonExe);
                                selectfolder.getFileTreeMap().put(nonExe.Name, nonExe);
                                int cnt = selectfolder.getFileNum();
                                cnt++;
                                selectfolder.setFileNum(cnt);
                                selectfolder.Size += nonExe.Size;
                            }
                        }
                        System.out.println("New success");
                    }
                    case "Select" -> {
                        String[] selectFile = new String[2];
                        selectFile[0] = scanner.nextLine();
                        selectFile[1] = scanner.nextLine();
                        if (selectFile[0].equals("folder")) {
                            selectfolder = getFolder(selectFile[1]);
                            isselect = 1;
                            isfolder = 1;
                            isink = 0;
                            isexe = 0;
                            isnonexe = 0;
                        }
                        if (selectFile[0].equals("ink")) {
                            selectink = getInk(selectFile[1]);
                            isselect = 1;
                            isfolder = 0;
                            isink = 1;
                            isexe = 0;
                            isnonexe = 0;
                        }
                        if (selectFile[0].equals("exe")) {
                            selectexe = getExe(selectFile[1]);
                            isselect = 1;
                            isfolder = 0;
                            isink = 0;
                            isexe = 1;
                            isnonexe = 0;
                        }
                        if (selectFile[0].equals("nonexe")) {
                            selectnonexe = getNonExe(selectFile[1]);
                            isselect = 1;
                            isfolder = 0;
                            isink = 0;
                            isexe = 0;
                            isnonexe = 1;
                        }
                        System.out.println("Select success");
                    }
                    case "Open" -> {
                        if (isselect == 0) {
                            System.out.println("Cannot perform operation, Select first");
                        }
                        else if (isselect == 1 && isfolder == 1) {
                            for (File file: selectfolder.getFileTreeMap().values()) {
                                System.out.println("[Name:"+file.Name+"] "+"[Type:"+file.Type+"]");
                            }
                        }
                        else if (isselect == 1 && isink == 1) {
                            if (selectink.getFile().Type.equals("folder")) {
                                for (File file: getFolder(selectink.getFile().Name).getFileTreeMap().values()) {
                                    System.out.println("[Name:"+file.Name+"] "+"[Type:"+file.Type+"]");
                                }
                            }
                            else {
                                System.out.println(selectink.getFile().Content);
                            }

                        }
                        else if (isselect == 1 && isexe == 1) {
                            System.out.println(selectexe.Content);
                        }
                        else if (isselect == 1 && isnonexe == 1) {
                            System.out.println("File cannot be opened");
                        }
                        isopen = 1;
                    }
                    case "Close" -> {
                        if (isselect == 0 && isopen == 0) {
                            System.out.println("Error");
                        }
                        else if (isselect == 1 && isopen == 1) {
                            System.out.println("close success");
                            isopen = 0;
                        }
                    }
                    case "Print" -> {
                        if (isselect == 0) {
                            System.out.println("Cannot perform operation, Select first");
                        }
                        else if (isselect == 1 && isfolder == 1) {
                            System.out.println("[Name:"+selectfolder.Name+"] "+"[Type:"+selectfolder.Type+"] "+"[Size:"+selectfolder.Size+"] "+"[Time:"+selectfolder.Time+"] "+"[Location:"+selectfolder.Location+"] "+"[FolderNum:"+selectfolder.getFoldNum()+"] "+"[FileNum:"+selectfolder.getFileNum()+"]");
                        }
                        else if (isselect == 1 && isink == 1) {
                            System.out.println("[Name:"+selectink.Name+"] "+"[Type:"+selectink.Type+"] "+"[Size:"+selectink.Size+"] "+"[Time:"+selectink.Time+"] "+"[Location:"+selectink.Location+"] "+"[Point:"+selectink.getFile().Name+"]");
                        }
                        else if (isselect == 1 && isexe == 1) {
                            System.out.println("[Name:"+selectexe.Name+"] "+"[Type:"+selectexe.Type+"] "+"[Size:"+selectexe.Size+"] "+"[Time:"+selectexe.Time+"] "+"[Location:"+selectexe.Location+"]");
                        }
                        else if (isselect == 1 && isnonexe == 1) {
                            System.out.println("[Name:"+selectnonexe.Name+"] "+"[Type:"+selectnonexe.Type+"] "+"[Size:"+selectnonexe.Size+"] "+"[Time:"+selectnonexe.Time+"] "+"[Location:"+selectnonexe.Location+"]");
                        }
                    }
                }
            }
        }
    }
}
