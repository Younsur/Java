import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Room {
    private int num;

    public void setNum(int num) {
        this.num = num;
    }

    public int getNum() {
        return num;
    }
}

class SpiralAbyss extends Room{
    List<Person> partner = new ArrayList<>();

    public void print(){
        for (Person person: partner) {
            System.out.println("[Name:"+person.getName()+"] "+"[Age:"+person.getAge()+"] "+"[Gender:"+person.getSex()+"]");
        }
    }
}

class Person {
    private String name;
    private String age;
    private String sex;

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getSex() {
        return sex;
    }
}

public class Test {
    public static void main(String[] args) {
        SpiralAbyss spiralAbyss = new SpiralAbyss();
        Scanner scanner1 = new Scanner(System.in);
        int MaxNum = scanner1.nextInt();
        spiralAbyss.setNum(MaxNum);
        Scanner scanner2 = new Scanner(System.in);
        Scanner scanner3 = new Scanner(System.in);
        Scanner scanner4 = new Scanner(System.in);
        for (int i = 0; i <= spiralAbyss.getNum() + 1; i++) {
            Person person = new Person();
            person.setName(scanner2.nextLine());
            person.setAge(scanner3.nextLine());
            person.setSex(scanner4.nextLine());
            if (spiralAbyss.partner.size() < spiralAbyss.getNum()){
                spiralAbyss.partner.add(person);
            }
            else {
                System.out.println("Add failed, the number of people is full");
                break;
            }
        }
        spiralAbyss.print();
    }
}