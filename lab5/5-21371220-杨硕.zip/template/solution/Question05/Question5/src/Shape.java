import java.util.Scanner;

public abstract class Shape {
        protected double a;
        protected double b;

        public Shape() { this(0.0, 0.0); }
        public Shape(double a, double b) {
            this.a = a;
            this.b = b;
        }

        /** calcArea
         * ������״�����
         * @return ���
         */
        abstract public double calcArea();

    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }
    /* ������Ҫ�ķ��������� getter �� setter */
}

class Rectangle extends Shape {


    @Override
    public double calcArea() {
        return getA() * getB();
    }
}

class Rhombus extends Shape {

    @Override
    public double calcArea() {
        return getA() * getB() / 2;
    }
}

class Ellipse extends Shape {
    @Override
    public double calcArea() {
        return 3.14 * getA() * getB();
    }
}

