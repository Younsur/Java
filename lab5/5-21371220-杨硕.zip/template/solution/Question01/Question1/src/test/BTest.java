package test;
import com.oo.bb.*;
public class BTest {
	public static void main(String[] args) {
		System.out.println("b test starts");
		B b = new B(1);
		System.out.println("yeah~");
	}
}