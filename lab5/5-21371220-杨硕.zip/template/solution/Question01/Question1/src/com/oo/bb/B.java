package com.oo.bb;
import com.oo.aa.*;
public class B extends A{
	public B(int i) {
		super(i);
		System.out.println("B" + i);
	}
}